﻿using Maze.Logic;
using System;

namespace RecursiveBacktracker
{
    class Program
    {
        static void Main(string[] args)
        {
            var g = new Grid(10, 10);
            g.Generate();
            g.Print(g.Cells);
            Console.ReadKey();
        }
    }
}
