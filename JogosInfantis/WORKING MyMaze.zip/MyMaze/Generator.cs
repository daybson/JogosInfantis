﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyMaze
{
    public class Generator
    {
        public struct Vector2Int
        {
            public int x;
            public int y;

            public Vector2Int(int x, int y)
            {
                this.x = x;
                this.y = y;
            }

            public static bool operator !=(Vector2Int a, Vector2Int b)
            {
                return a.x != b.x || a.y != b.y;
            }

            public static bool operator ==(Vector2Int a, Vector2Int b)
            {
                return a.x == b.x && a.y == b.y;
            }

            public override bool Equals(object obj)
            {
                return this == (Vector2Int)obj;
            }
        }

        public enum Directions
        {
            Up,
            Down,
            Left,
            Right
        }

        public int width { get; private set; }
        public int height { get; private set; }

        public int[][] Cells;

        public Vector2Int entry;
        public Vector2Int exit;
        int WALL = 1;
        int STREET = 0;
        int PATH = 2;



        /// <summary>
        /// Funciona melhor com valores ímpares
        /// </summary>
        /// <param name="height"></param>
        /// <param name="width"></param>
        public Generator(int height, int width)
        {
            this.width = width;
            this.height = height;
        }


        public void Generate()
        {
            Cells = new int[width][];

            //inicializa 
            for (int i = 0; i < width; i++)
            {
                Cells[i] = new int[height];
                for (int j = 0; j < height; j++)
                    Cells[i][j] = WALL;
            }

            Random rand = new Random();

            //celula inicial aleatoria
            int r = rand.Next(width);
            while (r % 2 == 0)
            {
                r = rand.Next(width);
            }

            int c = rand.Next(height);
            while (c % 2 == 0)
            {
                c = rand.Next(height);
            }

            Cells[r][c] = STREET;

            RecursiveDigging(r, c);
        }


        public void RecursiveDigging(int r, int c)
        {
            var randDirs = GetRandomDirections();

            for (int i = 0; i < randDirs.Length; i++)
            {
                switch (randDirs[i])
                {
                    case 1: //up
                        if (r - 2 <= 0)
                            continue;

                        if (Cells[r - 2][c] != STREET)
                        {
                            Cells[r - 2][c] = STREET;
                            Cells[r - 1][c] = STREET;
                            RecursiveDigging(r - 2, c);
                        }
                        break;

                    case 2: //right
                        if (c + 2 >= width - 1)
                            continue;
                        if (Cells[r][c + 2] != STREET)
                        {
                            Cells[r][c + 2] = STREET;
                            Cells[r][c + 1] = STREET;
                            RecursiveDigging(r, c + 2);
                        }
                        break;

                    case 3: //down
                        if (r + 2 >= height - 1)
                            continue;
                        if (Cells[r + 2][c] != STREET)
                        {
                            Cells[r + 2][c] = STREET;
                            Cells[r + 1][c] = STREET;
                            RecursiveDigging(r + 2, c);
                        }
                        break;

                    case 4: //left
                        if (c - 2 <= 0)
                            continue;
                        if (Cells[r][c - 2] != STREET)
                        {
                            Cells[r][c - 2] = STREET;
                            Cells[r][c - 1] = STREET;
                            RecursiveDigging(r, c - 2);
                        }
                        break;
                }
            }
        }


        public bool RatSolver(Vector2Int position, Directions direction)
        {
            if (position == exit)
            {
                Cells[exit.x][exit.y] = PATH;
                return true;
            }

            if (IsSafeToGo(position))
            {
                var previous = Cells[position.x][position.y];
                Cells[position.x][position.y] = PATH;

                if (direction != Directions.Up && RatSolver(new Vector2Int(position.x + 1, position.y), Directions.Down))
                {
                    //go down
                    return true;
                }
                //else go down
                if (direction != Directions.Left && RatSolver(new Vector2Int(position.x, position.y + 1), Directions.Right))
                {
                    //go right
                    return true;
                }
                if (direction != Directions.Down && RatSolver(new Vector2Int(position.x - 1, position.y), Directions.Up))
                {
                    //go up
                    return true;
                }
                if (direction != Directions.Right && RatSolver(new Vector2Int(position.x, position.y - 1), Directions.Left))
                {
                    //go left
                    return true;
                }

                //if none of the options work out BACKTRACK undo the move
                Cells[position.x][position.y] = previous;
                return false;
            }

            return false;
        }


        public void FindSolution(Vector2Int entry, Vector2Int exit)
        {
            var randDirs = GetRandomDirections();
            var previous = Cells[entry.x][entry.y];

            Cells[entry.x][entry.y] = PATH;

            if (entry == exit)
            {
                Cells[exit.x][exit.y] = PATH;
                return;
            }

            for (int i = 0; i < randDirs.Length; i++)
            {
                switch (randDirs[i])
                {
                    case 1: //up

                        if (entry.y - 1 <= 0 || Cells[entry.x][entry.y - 1] != STREET)
                            continue;

                        entry = new Vector2Int(entry.x, entry.y - 1);
                        Cells[entry.x][entry.y] = PATH;
                        FindSolution(entry, exit);
                        break;

                    case 2: //right
                        if (entry.x + 1 >= width - 1 || Cells[entry.x + 1][entry.y] != STREET)
                            continue;

                        entry = new Vector2Int(entry.x + 1, entry.y);
                        Cells[entry.x][entry.y] = PATH;
                        FindSolution(entry, exit);
                        break;

                    case 3: //down
                        if (entry.y + 1 >= height - 1 || Cells[entry.x][entry.y + 1] != STREET)
                            continue;

                        entry = new Vector2Int(entry.x, entry.y + 1);
                        Cells[entry.x][entry.y] = PATH;
                        FindSolution(entry, exit);
                        break;

                    case 4: //left
                        if (entry.x - 1 <= 0 || Cells[entry.x - 1][entry.y] != STREET)
                            continue;

                        entry = new Vector2Int(entry.x - 1, entry.y);
                        Cells[entry.x][entry.y] = PATH;
                        FindSolution(entry, exit);
                        break;
                }
            }

            Cells[entry.x][entry.y] = previous;
            return;
        }


        private bool IsSafeToGo(Vector2Int position)
        {
            if (position.x >= 0 &&
                position.y >= 0 &&
                position.x < width &&
                position.y < height &&
                Cells[position.x][position.y] != WALL)
                return true;

            return false;
        }

        private int[] GetRandomDirections()
        {
            var randoms = new List<int>() { 1, 2, 3, 4 };
            return randoms.OrderBy(x => new Random().Next(4)).ToArray();
        }


        public void SortBorderPoint()
        {
            var rand = new Random();
            var heightFirstColumn = rand.Next(2, width - 2);
            var heightLastColumn = rand.Next(2, width - 2);

            entry = new Vector2Int(0, heightFirstColumn);
            exit = new Vector2Int(width - 1, heightLastColumn);

            Cells[entry.x][entry.y] = 0;
            Cells[entry.x + 1][entry.y] = 0;

            Cells[exit.x][exit.y] = 0;
            Cells[exit.x - 1][exit.y] = 0;
        }



        public new string ToString()
        {
            var s = new StringBuilder();

            for (int r = 0; r < height; r++)
            {
                var line = "";

                for (int c = 0; c < width; c++)
                {
                    switch (Cells[r][c])
                    {
                        case 0:
                            line += " ";
                            break;
                        case 1:
                            line += "#";
                            break;
                        case 2:
                            line += "°";
                            break;
                    }
                }

                s.AppendLine(line);
            }

            return s.ToString();
        }

    }
}