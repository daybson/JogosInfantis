﻿using System;
using System.IO;
using System.Text;
using static MyMaze.Generator;

namespace MyMaze
{


    class Program
    {
        static void Main(string[] args)
        {
            Generator g = new Generator(15, 15);

            g.Generate();
            g.SortBorderPoint();

            //Console.WriteLine(g.ToString());

            //Console.ReadKey();
            Console.Clear();
            g.RatSolver(g.entry, Directions.Down);
            Console.WriteLine(g.ToString());

            //File.WriteAllText($"maze{g.width}{g.height}.txt", g.ToString());

            //StringBuilder s = new StringBuilder(File.ReadAllText($"maze{g.width}{g.height}.txt"));
            //Console.WriteLine(s.ToString());

            Console.ReadKey();
        }
    }
}
